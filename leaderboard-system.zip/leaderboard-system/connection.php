<?php

session_start();

$conn = mysqli_connect('localhost', 'root', '', 'leaderboard_system');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

date_default_timezone_set('Asia/Kolkata');

?>