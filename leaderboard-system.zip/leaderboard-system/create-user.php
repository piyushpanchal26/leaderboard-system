<?php
include 'connection.php';

if (isset($_REQUEST['submit'])) {
    $username = $_REQUEST['username'];
    $points = $_REQUEST['points'];
    $wins = $_REQUEST['wins'];
    $losses = $_REQUEST['losses'];

    $insert = "insert into user_stats(username, points, wins, losses) values('$username','$points','$wins','$losses')";

    if (mysqli_query($conn, $insert)) {
        $_SESSION['status'] = "success";
        $_SESSION['msg'] = "New User Add Successfully.";
    } else {
        $_SESSION['status'] = "error";
        $_SESSION['msg'] = "Can't Add New User.";
    }

    header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="col-6">
                <div class="card p-4 shadow">
                    <h3>Add New User</h3>

                    <form action="" method="POST" class="mt-3">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter Username">
                        </div>
                        <div class="mb-3">
                            <label for="points" class="form-label">Points</label>
                            <input type="text" class="form-control numberonly" id="points" name="points" placeholder="Enter Number of Points">
                        </div>
                        <div class="mb-3">
                            <label for="wins" class="form-label">Wins</label>
                            <input type="text" class="form-control numberonly" id="wins" name="wins" placeholder="Enter Number of Wins">
                        </div>
                        <div class="mb-3">
                            <label for="losses" class="form-label">Losses</label>
                            <input type="text" class="form-control numberonly" id="losses" name="losses" placeholder="Enter Number of Losses">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                        <a href="index.php" class="btn btn-secondary">Back</a>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.numberonly').keypress(function(event) {
                if (event.which < 48 || event.which > 57) {
                    event.preventDefault();
                }
            });
        });
    </script>
</body>

</html>