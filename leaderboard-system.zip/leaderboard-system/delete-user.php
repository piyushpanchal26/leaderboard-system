<?php
include 'connection.php';

if(isset($_REQUEST['did']) && $_REQUEST['did']!=''){
    $userid= $_REQUEST['did'];
    $delete_user= "delete from user_stats where userid=".$userid;    

    if (mysqli_query($conn, $delete_user)) {
        $_SESSION['status'] = "success";
        $_SESSION['msg'] = "User Deleted Successfully.";
    } else {
        $_SESSION['status'] = "error";
        $_SESSION['msg'] = "Can't Delete User.";
    }

    header('location:index.php');
}
?>