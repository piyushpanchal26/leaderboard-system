<?php
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="col-10">
                <div class="card p-4 shadow">
                    <div class="row  mb-3">
                        <div class="col-6">
                            <h3>Leaderboard System</h3>
                        </div>
                        <div class="col-6 text-end">
                            <a href="create-user.php" class="btn btn-sm btn-primary">Add New User</a>
                        </div>
                    </div>

                    <?php
                    if (isset($_SESSION['msg']) && isset($_SESSION['status'])) {
                        if($_SESSION['status'] == 'success'){
                            $class= 'success';
                        }elseif ($_SESSION['status'] == 'error') {
                            $class= 'warning';
                        }else{
                            $class= 'info';
                        }
                    ?>
                        <div class="alert alert-<?php echo $class; ?> alert-dismissible fade show" role="alert">
                            <strong><?php echo $_SESSION['msg']; ?></strong>
                            <?php unset($_SESSION['msg']); unset($_SESSION['status']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php }
                    ?>

                    <table id="leaderboard_table" class="table table-hover table-bordered text-center">
                        <thead class="table-dark">
                            <tr>
                                <th>Rank</th>
                                <th>Username</th>
                                <th>Points</th>
                                <th>Wins</th>
                                <th>Losses</th>
                                <th>Last Activity</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sel_users = "select * from user_stats order by points desc, wins desc, losses asc, last_activity desc";
                            $res_users = mysqli_query($conn, $sel_users);
                            $i = 1;
                            while ($row_user = mysqli_fetch_array($res_users)) {
                            ?>
                                <tr>
                                    <th><?php echo $i++; ?></th>
                                    <td><?php echo $row_user['username']; ?></td>
                                    <td><?php echo $row_user['points']; ?></td>
                                    <td><?php echo $row_user['wins']; ?></td>
                                    <td><?php echo $row_user['losses']; ?></td>
                                    <td><?php echo $row_user['last_activity']; ?></td>
                                    <td>
                                        <a href="update-user.php?eid=<?php echo $row_user['userid']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                        <a href="delete-user.php?did=<?php echo $row_user['userid']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are You Sure?')">Delete</a>
                                    </td>
                                </tr>
                            <?php }
                            ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/2.2.1/js/dataTables.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#leaderboard_table').DataTable();
        });
    </script>
</body>

</html>