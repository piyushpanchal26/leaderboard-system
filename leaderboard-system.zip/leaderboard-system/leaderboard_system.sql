-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2025 at 06:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leaderboard_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_stats`
--

CREATE TABLE `user_stats` (
  `userid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `points` int(11) NOT NULL,
  `wins` int(11) NOT NULL,
  `losses` int(11) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_stats`
--

INSERT INTO `user_stats` (`userid`, `username`, `points`, `wins`, `losses`, `last_activity`) VALUES
(1, 'UserA', 150, 25, 5, '2024-01-14 21:30:00'),
(2, 'UserB', 120, 20, 8, '2024-01-14 04:45:00'),
(3, 'UserC', 150, 22, 6, '2024-01-14 22:15:00'),
(4, 'UserD', 130, 18, 7, '2024-01-13 01:00:00'),
(5, 'UserE', 120, 25, 10, '2024-01-15 00:30:00'),
(6, 'UserF', 140, 20, 5, '2024-01-14 23:00:00'),
(7, 'UserG', 130, 18, 9, '2024-01-14 07:30:00'),
(8, 'UserH', 110, 15, 7, '2024-01-14 03:15:00'),
(9, 'UserI', 140, 22, 8, '2024-01-13 06:45:00'),
(10, 'UserJ', 130, 19, 6, '2024-01-14 22:45:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_stats`
--
ALTER TABLE `user_stats`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_stats`
--
ALTER TABLE `user_stats`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
