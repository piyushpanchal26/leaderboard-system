<?php
include 'connection.php';

if(isset($_REQUEST['eid']) && $_REQUEST['eid']!=''){
    $id= $_REQUEST['eid'];
    $sel_user= "select * from user_stats where userid=".$id;
    $res_user= mysqli_query($conn, $sel_user);
    $row_user= mysqli_fetch_array($res_user, MYSQLI_ASSOC);
}

if(isset($_REQUEST['update'])){
    $userid= $_REQUEST['userid'];
    $username= $_REQUEST['username'];
    $points= $_REQUEST['points'];
    $wins= $_REQUEST['wins'];
    $losses= $_REQUEST['losses'];
    $last_activity= date('Y-m-d H:i:s');

    $update= "update user_stats set username='$username', points='$points', wins='$wins', losses='$losses', last_activity='$last_activity' where userid=".$userid;

    if(mysqli_query($conn, $update)){
        $_SESSION['status'] = "success";
        $_SESSION['msg'] = "User Updated Successfully.";
    }else{
        $_SESSION['status'] = "error";
        $_SESSION['msg'] = "Can't Update User.";
    }

    header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="col-6">
                <div class="card p-4 shadow">
                    <h3>Update User</h3>

                    <form action="" method="POST" class="mt-3">
                        <input type="hidden" name="userid" value="<?php echo $_REQUEST['eid']; ?>">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter Username" value="<?php echo $row_user['username']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="points" class="form-label">Points</label>
                            <input type="text" class="form-control numberonly" id="points" name="points" placeholder="Enter Number of Points" value="<?php echo $row_user['points']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="wins" class="form-label">Wins</label>
                            <input type="text" class="form-control numberonly" id="wins" name="wins" placeholder="Enter Number of Wins" value="<?php echo $row_user['wins']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="losses" class="form-label">Losses</label>
                            <input type="text" class="form-control numberonly" id="losses" name="losses" placeholder="Enter Number of Losses" value="<?php echo $row_user['losses']; ?>">
                        </div>
                        <button type="submit" name="update" class="btn btn-success">Update</button>
                        <a href="index.php" class="btn btn-secondary">Back</a>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.numberonly').keypress(function(event) {
                if (event.which < 48 || event.which > 57) {
                    event.preventDefault();
                }
            });
        });
    </script>
</body>

</html>